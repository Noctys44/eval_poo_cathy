
-- --------------------------------------------------------

--
-- Structure de la table `contest`
--

CREATE TABLE `contest` (
  `id` int(5) NOT NULL,
  `game_id` int(10) NOT NULL,
  `start_date` datetime NOT NULL,
  `winner_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `contest`
--

INSERT INTO `contest` (`id`, `game_id`, `start_date`, `winner_id`) VALUES
(1, 23, '2019-12-25 13:49:55', 2),
(2, 25, '2020-12-25 13:49:55', 0);
